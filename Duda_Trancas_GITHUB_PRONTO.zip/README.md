# Duda Tranças

Site em React + Vite + TypeScript, com página pública, painel em `/admin` e funções de servidor em `netlify/functions`.

## Enviar para o GitHub

1. Crie um repositório no GitHub.
2. Extraia este ZIP. Os arquivos `package.json`, `package-lock.json`, `index.html`, `main.tsx` e `netlify.toml` devem ficar diretamente na raiz do repositório (não dentro de uma segunda pasta `duda`).
3. Envie todos os arquivos e pastas do projeto para o repositório. Não envie `node_modules`, `dist`, arquivos `.env` ou tokens/senhas.
4. O workflow em `.github/workflows/ci.yml` executará `npm ci` e `npm run build` a cada push e pull request, mostrando erros de compilação na aba **Actions**.

## Executar localmente

Requer Node.js 22:

```bash
npm ci
npm run dev
```

Validar a compilação:

```bash
npm run build
```

## Publicar o site

**O GitHub armazena o código; ele não executa as Netlify Functions.** Como o projeto usa funções para agenda/admin, para manter esses recursos funcionando, conecte o repositório GitHub à Netlify. A configuração `netlify.toml` já indica `npm run build`, publicação de `dist` e a pasta `netlify/functions`.

Na Netlify, configure as variáveis de ambiente necessárias:

- `TURSO_DATABASE_URL`: URL do banco remoto Turso (`libsql://...`)
- `TURSO_AUTH_TOKEN`: token de acesso ao banco Turso
- `ADMIN_KEY`: chave/senha longa e exclusiva para administração

Depois de definir as variáveis, publique novamente. Nunca coloque os valores reais em arquivos versionados ou em variáveis `VITE_*`.

## GitHub Pages

GitHub Pages serve conteúdo estático e não executa as funções de servidor deste projeto. Publicar somente no GitHub Pages não habilita o banco, o agendamento nem o painel que depende das funções. Use a Netlify conectada ao GitHub para o projeto completo.
